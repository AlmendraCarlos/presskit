ALMENDR4C4RLOS — PRESS KIT
==========================

CONTENIDO / CONTENTS
- biografia.pdf / biography.pdf  (ES + EN)
- fotos/  (high-res promo & live shots)

CONTACTO / CONTACT
Email:     almendra.carlos.92@gmail.com
WhatsApp:  +54 9 362 529-0364
Instagram: @almendr4c4rlos
YouTube:   youtube.com/@almendr4c4rlos

© ALMENDR4C4RLOS
